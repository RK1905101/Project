
public class Lamp {
	boolean isOn;
	
	void turnOn(){
		isOn = true;
		System.out.println("Light is on");
	}
	void turnOff(){
		isOn = false;
		System.out.println("Light is off");
	}
}

public static void main(String args[]) {
	Lamp led=new lamp();
	Lamp 
}